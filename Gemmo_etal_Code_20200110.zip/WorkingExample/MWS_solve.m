%%%%%%%%%%%%%%%%%%
%% Continuous Construction of MWS
%%%%%%%%%%%%%%%%%%
% Code computes the MWS equilibrium allocation with coverage q(c) and price
% y(c) for type c
% M = Mandate / lower-bound for insurance coverage q

%% Preparation: every type's first-best
tic
q_FB = NaN*ones(N,1);
for i=1:N
    q_FB(i) = fminsearch(@(q) -V(q,q*c_discrete(i),c_discrete(i)),1);  %give highest cost type the first-best contract at comp price
end

%% Preparation: empty variables
V_bar = NaN*ones(N,1);          %this will be the final minimum utility function
q_final = NaN*ones(N,1);        %will store final contracts
y_final = NaN*ones(N,1);        %will store final prices

q_0 = NaN*ones(N,1);            %will store contracts (when min util not binding)
y_0 = NaN*ones(N,1);            %will store prices  (when min util not binding)
T_0 = NaN*ones(N,1);            %the surplus in step 1 (to determine Pareto-improving transfers)
eta_0 = NaN*ones(N,1);

%% Step 0 (Initialization with highest cost type)
q_0(N) = max(M,q_FB(N));                    %give highest cost type the first-best contract at comp price
y_0(N) = q_0(N)*c_upper_bar;                %fair price
V_bar(N) = V(q_0(N),y_0(N),c_upper_bar);    %highest cost type's utility
T_0(N) = 0;
eta_0(N) = 0;
c_break_even = [];                          %these are the lowest and largest cost types in each break even interval
c_break_even(:,1) = N*ones(2,1);            %initialize with largest cost type

current_n = N;
%% Step 1 (relaxed problem; minimum util constraint not binding)
for n = (current_n-1):-1:1   %start at the highest c type we have solved before and the go down to determine the q_0 allocation
    c_dummy = c_discrete(n);
    eta_0(n) = (1-sum(f_discrete(1:n)));
    q_0(n) = max(M,fmincon(@(q) ((v_q(q,c_dummy)-c_dummy)/(v_qc(q,c_dummy)) - eta_0(n)/(f_discrete(n)/DELTA))^2, q_0(n+1),[],[],[],[],0,q_FB(N),[],options));  %uses discretized distribution
    if min(diff(q_0(n:end)))<-1e-5
        %there is bunching -> use Mussa&Rosen ironing techniques
        q_new = [NaN*ones(n-1,1);ironing(c_discrete(n:end),q_0(n:end),v_q,v_qc,f_discrete(n:end),DELTA,eta_0(n:end))];
        for h=(current_n-1):-1:(n+1)  %recompute prices
            y_0(h) = max(0,y_0(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1)));
        end
    else
        q_new = q_0;
    end
    y_0(n) = y_0(n+1) + v_q(q_new(n+1),c_discrete(n+1))*(q_new(n)-q_new(n+1));  %this is discrete integral of incentive compatibility constraint, y' = v_q*q'
    T_0(n) = sum((y_0(n:N) - c_discrete(n:N).*q_new(n:N)).*f_discrete(n:N))/sum(f_discrete(n:N));  %the total profit in [c_dummy, c_upper_bar] for this allocation
    if ((T_0(n)-T_0(n+1))/T_0(n+1)>=-1e-6)  %T0 still weakly decreasing in n
        V_bar(n) = v(q_new(n),c_discrete(n)) - y_0(n) + T_0(n);  %strictly above c_1, we have thus found reservation utilities
    else
        i_1 = n+1;
        break
    end
end

% determine cut-off value to find c^1 = c_discrete(i_1)
if n==1  %increasing for all
    i_1=1;
end

%re-do ironing for the allocation [i_1,N] (to determine EQ allocation)
q_new = q_0;
if min(diff(q_0(i_1:end)))<-1e-5
    %there is bunching -> use Mussa&Rosen ironing techniques
    q_new(i_1:end) = ironing(c_discrete(i_1:end),q_0(i_1:end),v_q,v_qc,f_discrete(i_1:end),DELTA,eta_0(i_1:end));
    for h=(current_n-1):-1:i_1  %recompute prices
        y_0(h) = y_0(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1));
    end
end

%record for final EQ allocation
if i_1<=(current_n-1)
    q_final(i_1:(current_n)) = q_new(i_1:(current_n));   %the final allocation if i_1 is the upper bound of break even group
    y_final(i_1:(current_n)) = y_0(i_1:(current_n))-T_0(i_1);
end
c_break_even = [[i_1;NaN],c_break_even];   %denote beginning of break even interval (i_1)


%% Step 2 (interval of break-even types)
q_1 = q_new;    %contract for break-even types
y_1 = y_final;
i_2 = i_1;
while (i_1>1 && i_2>1)  %as long as we have not looked at the whole population
    % (A) solve for q^1
    for j=(i_1-1):-1:1
        %q_1(j) = max(0, fmincon(@(q) (V(q,q*c_discrete(j),c_discrete(j+1)) - V(q_1(j+1),q_1(j+1)*c_discrete(j+1),c_discrete(j+1)))^2, q_1(j+1),[],[],[],[],0,q_FB(N),[],options));  %may alternatively use indifference curve as approximation for continuous construction
        q_1(j) = max(M,q_1(j+1) + (c_discrete(j)-c_discrete(j+1)) * q_1(j+1)/(v_q(q_1(j+1),c_discrete(j+1))-c_discrete(j+1)));
    end

    for j=(i_1-1):-1:1
            y_1(j) = y_1(j+1) + (c_discrete(j)-c_discrete(j+1)) * v_q(q_1(j+1),c_discrete(j+1)) * q_1(j+1)/(v_q(q_1(j+1),c_discrete(j+1))-c_discrete(j+1));
    end
    
    % (B) maximum c for this to be reservation utilities (which is the maximum c for this allocation to be Pareto optimal)
    dummy_f = f_discrete/DELTA.*(v_q(q_1,c_discrete)-c_discrete)./v_qc(q_1,c_discrete);                 %support function whose derivative is used in g
    dummy_f_c = (dummy_f(2:end)-dummy_f(1:(end-1)))./(c_discrete(2:(end))-c_discrete(1:(end-1)));       %numerical approximation of derivative of support function
    g = [dummy_f_c(1);dummy_f_c] + f_discrete/DELTA;
    
    i_2 = find(g<=0 & (1:N)'<i_1,1,'last');  %largest cost-type such that g<0
    i_2 = min(i_2,N);
    if isempty(i_2)  %if g always positive below i_1
        i_2 = 1;
    end
    if i_2<find(q_1<=M & (1:N)'<=i_1,1,'last')   %the first type to hit the mandate definitely ends break-even group
       i_2 = find(q_1<=M & (1:N)'<=i_1,1,'last');
    end
    
    %store new allocation
    V_bar(i_2:(i_1-1)) = V(q_1(i_2:(i_1-1)),y_1(i_2:(i_1-1)),c_discrete(i_2:(i_1-1)));
    q_final(i_2:(i_1-1)) = q_1(i_2:(i_1-1));
    y_final(i_2:(i_1-1)) = y_1(i_2:(i_1-1));
    c_break_even(2,1) = i_2;    %store lower point of break even interval
    
    %% Step 3
    if (i_2>1)
        % increment i_epsilon down
        i_eps = i_2;
        profit_i_eps = Inf;  %just for initialization
        i_delta = i_2;
        while(profit_i_eps>-1e-4*q_1(i_eps)*c_discrete(i_eps) && i_eps>=2)   % increment i_epsilon down as long as these conditions hold
            i_delta_old = i_delta;
            profit = Inf;  %just for initialization
            i_eps = i_eps-1; %consider the next-lowest cost type
            while(profit>0 && size(c_break_even,2)>1 && i_delta<N)  %increment i_delta up until total profit is zero or all break even intervals disappear
                i_delta = i_delta+1;
                y_2 = y_1;
                q_2 = q_1;
                eta = NaN*ones(i_delta,1);   %new multipliers (attention: now they are not necessarily zero at upper end)
                eta(i_delta) = (v_q(q_2(i_delta),c_discrete(i_delta))-c_discrete(i_delta))*f_discrete(i_delta)/DELTA / v_qc(q_2(i_delta),c_discrete(i_delta));
                for j=(i_delta-1):-1:i_eps
                    eta(j) = eta(i_delta) + (sum(f_discrete(1:i_delta)) - sum(f_discrete(1:j)));
                    c_dummy = c_discrete(j);
                    
                    %use FOC to solve for q
                    q_2(j) = max(M,fmincon(@(q) ((v_q(q,c_dummy)-c_dummy)/(v_qc(q,c_dummy)) - (eta(j))/(f_discrete(j)/DELTA))^2, q_FB(j),[],[],[],[],M,q_FB(N),[],options));  %uses discretized distribution
                    
                    if min(diff(q_2(j:end)))<-1e-6
                        %there is bunching -> use Mussa&Rosen-like ironing techniques
                        q_new = [NaN*ones(j-1,1);ironing(c_discrete(j:end),q_2(j:end),v_q,v_qc,f_discrete(j:end),DELTA,eta(j:end),i_delta-j+1)];
                        for h=(N-1):-1:(j+1)  %recompute prices
                            y_2(h) = y_2(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1));
                        end
                    else
                        q_new = q_2;
                    end
                        y_2(j) = y_2(j+1) + v_q(q_new(j+1),c_discrete(j+1))*(q_new(j)-q_new(j+1)); %this is discrete integral of incentive compatibility constraint, y' = v_q*q'
                end
                profit = sum((y_2(i_eps:i_delta) - q_new(i_eps:i_delta).*c_discrete(i_eps:i_delta)).*f_discrete(i_eps:i_delta));
                if i_delta>=c_break_even(1,1) %we just ate the whole break even interval
                    i_delta = c_break_even(2,2)-1;   %check for the next interval's lowest point
                    c_break_even = c_break_even(:,2:end);   %remove old break even interval
                end
            end
            if size(c_break_even,2)==1  %we ate all break even intervals
                break  %exit and determine below akin to Step 1
            else    %there still exist higher break even groups
                i_delta = i_delta-1;
                
                %recalculate allocation for this final i_delta
                y_2 = y_1;
                q_2 = q_1;
                eta = NaN*ones(i_delta,1);   %new multipliers (attention: now they are not necessarily zero at upper end)
                eta(i_delta) = (v_q(q_2(i_delta),c_discrete(i_delta))-c_discrete(i_delta))*f_discrete(i_delta)/DELTA / v_qc(q_2(i_delta),c_discrete(i_delta));
                for j=(i_delta-1):-1:i_eps
                    eta(j) = eta(i_delta) + (sum(f_discrete(1:i_delta)) - sum(f_discrete(1:j)));
                    c_dummy = c_discrete(j);
                    
                    %use FOC to solve for q
                    q_2(j) = max(M,fmincon(@(q) ((v_q(q,c_dummy)-c_dummy)/(v_qc(q,c_dummy)) - (eta(j))/(f_discrete(j)/DELTA))^2, q_FB(j),[],[],[],[],M,q_FB(N),[],options));  %uses discretized distribution
                    
                    if min(diff(q_2(j:end)))<-1e-6
                        %there is bunching -> use Mussa&Rosen-like ironing techniques
                        q_new = [NaN*ones(j-1,1);ironing(c_discrete(j:end),q_2(j:end),v_q,v_qc,f_discrete(j:end),DELTA,eta(j:end),i_delta-j+1)];
                        for h=(N-1):-1:(j+1)  %recompute prices
                            y_2(h) = y_2(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1));
                        end
                    else
                        q_new = q_2;
                    end
                    
                    y_2(j) = y_2(j+1) + v_q(q_new(j+1),c_discrete(j+1))*(q_new(j)-q_new(j+1)); %this is discrete integral of incentive compatibility constraint, y' = v_q*q'
                end
                V_bar(i_eps) = V(q_new(i_eps),y_2(i_eps), c_discrete(i_eps));
                profit_i_eps = y_2(i_eps) - q_new(i_eps)*c_discrete(i_eps);
            end
        end
        
        %if there is no break-even interval left, we determine V_bar as in
        %Step 1, basically searching for lower local maximum of T_0
        if size(c_break_even,2)==1 %we either ate all break even intervals             
            %determine allocation akin to Step 1
            current_n = N;
            for n = (current_n-1):-1:1   %start at the highest c type we have solved before and the go down to determine the q_0 allocation
                c_dummy = c_discrete(n);
                eta_0(n) = (1-sum(f_discrete(1:n)));
                q_0(n) = max(M,fmincon(@(q) ((v_q(q,c_dummy)-c_dummy)/(v_qc(q,c_dummy)) - eta_0(n)/(f_discrete(n)/DELTA))^2, q_FB(n),[],[],[],[],0,q_FB(N),[],options));  %uses discretized distribution
                if min(diff(q_0(n:end)))<-1e-4
                    %there is bunching -> use Mussa&Rosen ironing techniques
                    q_new = [NaN*ones(n-1,1);ironing(c_discrete(n:end),q_0(n:end),v_q,v_qc,f_discrete(n:end),DELTA,eta_0(n:end))];
                    for h=(current_n-1):-1:(n+1)  %recompute prices
                        y_0(h) = y_0(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1));
                    end
                else
                    q_new = q_0;
                end
                y_0(n) = y_0(n+1) + v_q(q_new(n+1),c_discrete(n+1))*(q_new(n)-q_new(n+1));  %this is discrete integral of incentive compatibility constraint, y' = v_q*q'
                T_0(n) = sum((y_0(n:N) - c_discrete(n:N).*q_new(n:N)).*f_discrete(n:N))/sum(f_discrete(n:N));  %the total profit in [c_dummy, c_upper_bar] for this allocation
                if (T_0(n)>=(T_0(n+1)-1e-6)) || n>=i_eps   %T0 still weakly decreasing in n
                    V_bar(n) = v(q_new(n),c_discrete(n)) - y_0(n) + T_0(n);  %strictly above c_1, we have thus found reservation utilities
                elseif n<i_eps
                    i_1 = n+1;
                    break
                end
            end
            
            % determine cut-off value to find c^1 = c_discrete(i_1)
            if n==1  %increasing for all
                i_1=1;
            end
            
            %re-do ironing for the allocation [i_1,N] (to determine EQ allocation)
            q_new = q_0;
            if min(diff(q_0(i_1:end)))<0
                %there is bunching -> use Mussa&Rosen ironing techniques
                q_new(i_1:end) = ironing(c_discrete(i_1:end),q_0(i_1:end),v_q,v_qc,f_discrete(i_1:end),DELTA,eta_0(i_1:end));
                for h=(current_n-1):-1:i_1  %recompute prices
                    y_0(h) = y_0(h+1) + v_q(q_new(h+1),c_discrete(h+1))*(q_new(h)-q_new(h+1));
                end
            end
            
            %record for final EQ allocation
            if i_1<=(current_n-1)
                q_final(i_1:(current_n)) = q_new(i_1:(current_n));   %the final allocation if i_1 is the upper bound of break even group
                y_final(i_1:(current_n)) = y_0(i_1:(current_n))-T_0(i_1);
            end
            c_break_even = [[i_1;NaN],c_break_even];   %denote beginning of break even interval (i_1)
            
            i_delta=N;
            profit = -Inf;
            profit_i_eps = -Inf;
            q_1 = q_new;
            y_1 = y_0;
            
        else   %there is still one break-even interval left
            if i_eps>1
                i_eps = i_eps+1;  %take last pareto-improving transfer region
                i_delta = i_delta_old;
            end
            q_final(i_eps:(i_delta)) = q_new(i_eps:(i_delta));   %the final allocation if i_1 is the upper bound of break even group
            y_final(i_eps:(i_delta)) = y_2(i_eps:(i_delta));
            q_1 = q_new;
            y_1 = y_2;
            i_1 = i_eps;  %here, a new break even group begins
            c_break_even(2,1) = i_delta; %record new end of break even interval
            c_break_even = [[i_1;NaN],c_break_even];   %denote beginning of break even interval (i_1)
        end
    end
end

total_time_continuous_construction = toc;
