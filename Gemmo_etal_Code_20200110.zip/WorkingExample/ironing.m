function [q] = ironing(c_discrete,q,v_q,v_qc,f_discrete,DELTA,eta,max_cB)
%IRONING a la Mussa and Rosen
%INPUTS::
%c_discrete: discretized cost types
%q: coverage allocation for c_discrete
%v_q: function for marginal WTP (quasilinear preferences)
%v_qq: function for 2nd derivative of WTP (quasilinear preferences)
%f_discrete: weights for cost types c_discrete
%DELTA: discretization = diff(c_discrete)
%eta: multiplier on local IC from step 1
%max_cB: maximum cost-type to iron over

%OUTPUT:: q: ironed coverage allocation

N = length(c_discrete);
if nargin<8
    max_cB = Inf;
end
% first, locate all types of bunching mids (which are local maxima of q)
h = find(diff(q)<-1e-6);
g = find(diff(h)>1);
if isempty(g) && isempty(h)==0   %only one bunch
    bunches = h(1);
elseif isempty(g) && isempty(h)==1   %no bunches
    return
else   %several bunches
    bunches = [h(1); h(1+g)];
end

% second, locate all local minima
h = find(diff(q)>1e-6);
g = find(diff(h)>1);
minima = [1; h(1);h(g+1); N];

while(length(bunches)>=1)
    b = bunches(1);
    b_l = max(minima(minima<=b));    %lower bound
    b_u = min(minima(minima>b));     %upper bound
    [~,b_min] = min(q((1:N)>=b));
    b_min = b_min + (b-1);          %this is global minimum in the area above b
    
    diff_abs = NaN*ones(b_min-b+1,1);
    for j=0 : (b_min-b)
        if (b-j)>=1 && b-j >= b_l
            q_r = q(b-j);
        else
            q_r = q(b+j);
        end
        if q_r<=q(b)
            c_A = find(q>=q_r & (1:N)'>=1,1,'first');      
            if b_u<N
                c_B = find(q>=(q_r-1e-4) & (1:N)'>=b_u,1,'first');
            else
                c_B = N;   %if q is decreasing in last interval
            end
            
            if c_B<=max_cB
                xi = NaN*ones(c_B,1);  %xi is actually \xi' from Online Appendix B.3
                for h=c_A:c_B
                    xi(h) = (v_q(q_r,c_discrete(h))-c_discrete(h)).*f_discrete(h)/DELTA - eta(h).*v_qc(q_r,c_discrete(h));
                end
                %we try to find interval that integrates xi to zero
                diff_abs(j+1) = (sum(xi(c_A:c_B)))*DELTA;
            end
        end
    end
    
    [~,j_opt] = min(abs(diff_abs));
    j_opt = j_opt-1;
    if (b-j_opt)>=1
        q_r = q(b-j_opt);
    else
        q_r = q(b+j_opt);
    end
    c_A = find(q>=q_r & (1:N)'>=1,1,'first');       %before we had (1:N)>=b_l here
    c_B = find(q>=(q_r-1e-8) & (1:N)'>=b_u,1,'first');
    
    q(c_A:c_B) = q_r;
    bunches = bunches(2:end);
    if isempty(bunches)==0 && c_B>=bunches(1)
        while(isempty(bunches)==0)  %delete other bunches if we have already taken care of them
            if c_B<bunches(1)
                break
            else
                bunches = bunches(2:end);
            end
        end
    end
    minima(minima<c_B) = [];   %delete minima that are small
    minima = [1;c_B;minima];
end
end
