function [q,y] = AG_Mandate_implementation(MANDATE,q,y,v,c_discrete,f_discrete)
%% function to derive AG equilibrium allocation in presence of minimum coverage mandate
%INPUTS::
%MANDATE: minimum coverage mandate
%q: AG equilibrium contract allocation without mandate
%y: AG equilibrium price allocation without mandate
%v: function for consumer WTP (quasilinear preferences)
%c_discrete: discretized cost types
%f_discrete: weights for cost types c_discrete

%OUTPUTS:: 
%q: AG equilibrium contract allocation with mandate
%y: AG equilibrium price allocation with mandate

N = length(c_discrete);     %number of types
        
%% STEP 1: Assign mandate to all lower types
q(q<=MANDATE) = MANDATE;
MMB = find(abs(q-MANDATE)<1e-8,1,'last');   %the marginal mandate buyer

%% STEP 2: From marginal buyer, go upward 
for j=(MMB+1):N
    V = v(q(j),c_discrete(j)) - y(j);    %this is the AG allocation without mandate
    V_CF = v(MANDATE,c_discrete(j)) - sum(MANDATE.*c_discrete(1:j).*f_discrete(1:j))/sum(f_discrete(1:j));   %this is the counterfactual utility if j were to buy the mandate coverage as well
    if V_CF>V  %prefer mandate
        q(j) = MANDATE;
        MMB = j;
        %current_mandate_price = sum(MANDATE.*c_discrete.*current_mandate_buyers.*f_discrete)/sum(current_mandate_buyers.*f_discrete);
        %y(j) = current_mandate_price;
    else  %due to single-crossing, no higher risk type will buy, as well
        break
    end
end

mandate_price = sum(MANDATE.*c_discrete(1:MMB).*f_discrete(1:MMB))/sum(f_discrete(1:MMB));
y(1:MMB) = mandate_price;


end

