%% Compute AG equilibrium
% we know that with single-crossing and monotonicity of WTP in cost, 
% the AG equilibrium is fully determined by incentive compatibility constraints and every type breaks even

%% Initialization
c_discrete_AG = c_discrete;
f_discrete_AG = f_discrete;

%% Step 0 (highest risk type)
q_AG = NaN*ones(N,1);    %will store equilibrium coverage
q_AG(N) = fminsearch(@(q) -V(q,q*c_discrete_AG(N),c_discrete_AG(N)),1); %highest cost type receives first-best

current_n = N;
%% Step 1 (integrate down incentive compatibility constraints + impose break even condition)
options = optimoptions('fmincon','MaxFunctionEvaluations',5000,'Display','off');
for j = (current_n-1):-1:1   %start at the highest c type we have solved before and the go down to determine the q_AG allocation
    q_AG(j) = max(0, fmincon(@(q) (V(q,q*c_discrete_AG(j),c_discrete_AG(j+1)) - V(q_AG(j+1),q_AG(j+1)*c_discrete_AG(j+1),c_discrete_AG(j+1)))^2, q_AG(j+1),[],[],[],[],0,q_AG(N),[],options));
end
y_AG = q_AG.*c_discrete_AG;
V_final = V(q_AG,y_AG,c_discrete_AG);


