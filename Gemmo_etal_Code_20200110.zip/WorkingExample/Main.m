%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% NUMERICAL IMPLEMENTATION OF MWS and AG EQUILIBRIUM %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% accompanying Gemmo, Kubitza, Rothschild 2020
% this code solves for the MWS and AG equilibrium allocation in an
% exemplary setting, allowing for minimum coverage mandates
%% (1) Preferences 
gamma = 1e-5;   %risk aversion
sigma = 25000;  %risk standard deviation
v = @(q,c) q.*c-gamma/2*q.*(q-2)*sigma^2;   %maximum WTP for coverage q
v_q = @(q,c) c-(q-1).*(gamma*sigma^2);  %>0    
v_qq = @(q,c) -(gamma*sigma^2);   %<0
v_qc = @(q,c) 1;  %>0 

V = @(q,y,c) v(q,c)-y;      %utility from coverage q at price y
V_q = @(q,y,c) v_q(q,c);    %marginal utility w.r.t. q
V_qq = @(q,y,c) v_qq(q,c);  %second derivative
V_qc = @(q,y,c) v_qc(q,c);  %cross-derivative
PI = @(q,y,c) y-q.*c;       %profit from selling q at price y to type c

%% (2) Type distribution
c_lower_bar = 4340-1000;    %lowest cost type
c_upper_bar = 4340+1000;    %highest cost type
mu = (0.5*c_upper_bar+0.5*c_lower_bar); sigma=300;      %parameters for type distribution
F = @(c) (normcdf(c,mu,sigma)-normcdf(c_lower_bar,mu,sigma))/(normcdf(c_upper_bar,mu,sigma)-normcdf(c_lower_bar,mu,sigma));   %truncated normal type distribution


%% (3) Discretization of type space
N = 100;        %number of types (=fineness of discretization)
options = optimoptions('fmincon','MaxFunctionEvaluations',5000,'Display','off');
DELTA = (c_upper_bar - c_lower_bar)/(N+1-1);  %step size
c_discrete = (c_lower_bar:DELTA:(c_upper_bar))';   %this is the discretized type space
f_discrete = [F(c_discrete(2:(N+1)))-F(c_discrete(1:(N+1-1)))];  %discretized distribution, zero weight on highest cost type
c_discrete = c_discrete(1:N);
c_upper_bar = max(c_discrete);

%% (4) Solve for MWS
M = 0;    %mandate (minimum insurance coverage)
MWS_solve
q_MWS = q_final;
y_MWS = y_final;

%% (5) Solve for AG
AG_solve
[q_AG,y_AG] = AG_Mandate_implementation(M,q_AG,y_AG,v,c_discrete,f_discrete_AG);

%% (6) Illustration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 1: Equilibrium utility and V_bar
fig=figure();
left_color = [0,0,0];
right_color = [0,0,0];
set(fig,'defaultAxesColorOrder',[left_color; right_color]);
grid on
hold on

yyaxis right
ylim([min(f_discrete)-0.01,max(f_discrete)+0.01])
p4=plot(c_discrete(1:(end)), f_discrete,'-.blue');
ylabel('Type Distribution')

yyaxis left
p1=plot(c_discrete,V_bar,'--black','LineWidth',1.25);
p2=plot(c_discrete,V(q_MWS,y_MWS,c_discrete),'-black','LineWidth',1.25);
p3=plot(c_discrete,V(q_AG,y_AG,c_discrete),'-ored','LineWidth',1.25,'MarkerIndices',1:8:length(c_discrete));
xlabel('Cost Type')
ylabel('Expected Utility')

grid on
legende=legend([p1,p2,p3,p4],'$\bar V$ (MWS)','EQ Utility (MWS)','EQ Utility (AG)','Type Distribution','Location','NorthWest');
set(legende,'Interpreter','latex')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 2: Selection
fig=figure();
left_color = [0 0 0];
right_color = [0 0 1];
set(fig,'defaultAxesColorOrder',[left_color; right_color]);
hold on
grid on

%compute marginal cost of types purchasing coverage in MWS
delta = (max(q_MWS)-min(q_MWS))/23;
qs_MWS = (min(q_MWS)):delta:(max(q_MWS));
m_c_MWS = NaN*ones(length(qs_MWS),1);
f_c_MWS = NaN*ones(length(qs_MWS),1);
for j=1:length(qs_MWS)
    G=(q_MWS>=(qs_MWS(j)-delta/2) & q_MWS<(qs_MWS(j)+delta/2));
    m_c_MWS(j) = sum(c_discrete(G).*f_discrete(G))/sum(f_discrete(G));
    f_c_MWS(j) = max(1e-8,sum(f_discrete(G)))*2e3;
end

%compute marginal cost of types purchasing coverage in AG
delta = max(1e-5,(max(q_AG)-min(q_AG))/26);
qs_AG = (min(q_AG)):delta:(max(q_AG));
f_c_AG = NaN*ones(length(qs_AG),1);
m_c_AG = NaN*ones(length(qs_AG),1);
for j=1:length(qs_AG)
    G=(q_AG>=(qs_AG(j)-delta/2) & q_AG<(qs_AG(j)+delta/2));
    m_c_AG(j) = sum(f_discrete_AG(G).*c_discrete(G))/sum(f_discrete_AG(G));
    f_c_AG(j) = max(1e-4,sum(f_discrete_AG(G)))*2e3;
end


% plot
p1=plot(q_MWS,y_MWS./q_MWS,'black','LineWidth',1.25);
p2=scatter(qs_MWS,m_c_MWS,f_c_MWS,'black');
p3=plot(q_AG,y_AG./q_AG,'-red','LineWidth',1.25,'MarkerIndices',1:5:length(q_AG));
p4=scatter(qs_AG,m_c_AG,f_c_AG,'red','filled');
xlabel('Coverage','Interpreter','latex','FontSize',12)
ylabel('Marginal Price and Cost','Interpreter','latex','FontSize',12)
legend('Marginal Price (MWS)','Marginal Cost (MWS)','Marginal Price (AG)','Marginal Cost (AG)','Location','NorthWest')
