function psi = CoSPhistorical_final( return_bank, return_market, max_lag, q, VaR, minimum_observations )
%COSFHISTORICAL
%% Input parameters:
% return bank = returns of institution
% return_market = returns of system
% max_lag = maximum considered time lag
% q = confidence level of shock size
% VaR = possibility to input external Value-at-Risk (upper bound for shocks) or []
if nargin<=7
    minimum_observations=10/q;
end
L = max_lag+1;
n = length(return_bank);

%% Compute Upper Shock Bound
if n~=length(return_market)
    disp('Time Series do not have same length!')
    return
end
if nargin==4 || (exist('VaR','var')==1 && isempty(VaR))  %no Value-at-Risk in input
    VaR = [quantile(return_bank,q), quantile(return_market,q)];
end

%% Calculate PSI
psi = NaN*ones(L,1);
Y = NaN*ones(1,L);
return_market_original = return_market;
if n>=minimum_observations
    for i = 1:L
        n_max = n-(i-1);  %no. of samples, that we can use with lag (i-1)%that's the lag tau=i-1   
        Y(i) = sum(return_bank(1:n_max)<=VaR(1) & return_market(i:n)<=VaR(2));
        psi(i) = Y(i) / (q*sum(isnan(return_bank(1:n_max))==0));
    end
end

end
