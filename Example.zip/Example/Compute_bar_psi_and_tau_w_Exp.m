function [bar_psi,bar_tau,X] = Compute_bar_psi_and_tau_w_Exp(max_lag,M)
%max_lag: maximum time-lag between institution and system return
%M: vector of values of a systemic risk measure corresponding to time-lags 1 to tau_max

bar_tau=NaN;
bar_psi=NaN;

if sum(~isnan(M))>=(length(M)-2) %require at least max_lag-2 observations

    %% Fit to exponential function
        fitted = fit((1:max_lag)', M, 'exp1','Lower',[0,-Inf], 'Upper',[Inf,0]); %fit to exponential function
        X=coeffvalues(fitted);
        a = X(1);
        b = X(2); %the fitted function is a*exp(b*tau)

    if a>1e-8 && b<-1e-8 %else, we have no meaningful dynamics
        %% Bar Psi 
        bar_psi = a/(b*(max_lag-1))*(exp(b*max_lag)-exp(b));
        
        %% Bar Tau 
        if bar_psi>1e-5 %makes sure that dynamics are meaningful
            bar_tau = a/(b^2*bar_psi*(max_lag-1))*((b*max_lag-1)*exp(b*max_lag) - (b-1)*exp(b));
        end
    end    
end
end