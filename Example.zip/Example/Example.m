%% This is an example on how to use CoSP from Kubitza (2024)
%This script simulates time series rM and rI, with rI and rM being
%correlated with a time-lag of one period (e.g., day). Then, CoSP peaks for
%this day. The larger the time lag, the larger Spillover Duration. The
%larger the correlation, the larger Average Excess CoSP.

q = 0.05;       %shock level
max_lag = 50;  %maximum time lag between shocks
rM = randn(15001,1);
rI = randn(15000,1)+0.75*rM(2:end);   %firm returns
rM = rM(1:end-1);                     %system returns
minimum_observations = 0;
psi = CoSPhistorical( rI, rM, max_lag, q, [], minimum_observations)-q; %\Delta CoSP
[bar_psi,bar_tau,X] = Compute_bar_psi_and_tau_w_Exp(max_lag,psi(2:end)); %aggregate Measures

figure();				
plot(0:max_lag,psi);
hold on
plot(1:max_lag, X(1)*exp(X(2)*(1:max_lag)),'--');
plot(ones(1,2)*bar_tau, [0,max(psi)],'--black','Linewidth',2);
legend('\Delta CoSP','Fitted','Spillover Persistence')